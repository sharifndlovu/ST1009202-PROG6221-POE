﻿using System;

namespace TheRideYouRent
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintSheet.CollectValues(); // call method to begin
        }
    }
}
