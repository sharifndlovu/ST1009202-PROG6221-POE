﻿using System;
namespace TheRideYouRent
{
    public class Income
    {
        private static double monthlyIncome, taxDeduction;

        // constructor
        public Income(double monthlyIncome, double taxDeduction)
        {
            SetMonthlyIncome(monthlyIncome);
            SetTaxDeduction(taxDeduction);
        }


        public static double GetIncomeAfterTax()
        {
            return monthlyIncome - taxDeduction;
        }

        // getters and setters
        public void SetMonthlyIncome(double monthlyIncome)
        {
            Income.monthlyIncome = monthlyIncome;
        }

        public void SetTaxDeduction(double taxDeduction)
        {
            Income.taxDeduction = taxDeduction;
        }

        public double GetTaxDeduction()
        {
            return taxDeduction;
        }

        public double GetMonthlyIncome()
        {
            return monthlyIncome;
        }

    }
}
