﻿using System;
namespace TheRideYouRent
{
    public class Renting : IExpenses
    {
        public double rentCost;

        // constructor
        public Renting(double rentCost)
        {
            SetRentCost(rentCost);
        }

        // overridden method from expenses interfaces
        public double CalculateMonthlyRepayment()
        {
            return rentCost;
        }

        // setter for Rent Cost
        public void SetRentCost(double rentCost)
        {
            this.rentCost = rentCost;
        }
    }
}
