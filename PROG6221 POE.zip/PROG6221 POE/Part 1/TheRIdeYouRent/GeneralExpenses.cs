﻿using System;
namespace TheRideYouRent
{
    public class GeneralExpenses : IExpenses
    {
        private double groceries, waterAndElectricity, travelCost, cellPhoneBill, monthlyRepayment;

        // constructor
        public GeneralExpenses(double groceries, double waterAndElectricity, double travelCost, double cellPhoneBill)
        {
            SetGroceries(groceries);
            SetCellPhoneBill(cellPhoneBill);
            SetTravelCost(travelCost);
            SetWaterAndElectricity(waterAndElectricity);
        }

        // getters and setters
        public void SetGroceries(double groceries)
        {
            this.groceries = groceries;
        }

        public void SetWaterAndElectricity(double waterAndElectricity)
        {
            this.waterAndElectricity = waterAndElectricity;
        }

        public void SetTravelCost(double travelCost)
        {
            this.travelCost = travelCost;
        }

        public void SetCellPhoneBill(double cellPhoneBill)
        {
            this.cellPhoneBill = cellPhoneBill;
        }

        // overriden method from Expenses
        public double CalculateMonthlyRepayment()
        {
            monthlyRepayment = groceries + waterAndElectricity + travelCost + cellPhoneBill;
            return monthlyRepayment;
        }
    }
}
