﻿using System;
namespace TheRideYouRent
{
    public interface IExpenses // interface 
    {
        double CalculateMonthlyRepayment(); // interface method
    }
}
