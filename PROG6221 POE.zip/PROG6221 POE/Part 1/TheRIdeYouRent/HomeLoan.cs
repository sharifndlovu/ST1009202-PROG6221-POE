﻿using System;
namespace TheRideYouRent
{
    public class HomeLoan : IExpenses
    {
        private double propertyPrice, deposit, monthlyRepayment, amountRemainingToPay, tempResult;
        private int monthsToPay, interestRate;
        private bool RedLoanAlert;

        // constructor
        public HomeLoan(double propertyPrice, double deposit, int interestRate, int monthsToPay)
        {
            SetPropertyPrice(propertyPrice);
            SetDeposit(deposit);
            SetMonthsToPay(monthsToPay);
            SetInterestRate(interestRate);
        }

        public double GetHomeLoanRepayment()
        {
            return monthlyRepayment;
        }

        // overriden method from Expenses interface
        public double CalculateMonthlyRepayment()
        {
            amountRemainingToPay = propertyPrice - deposit;

            tempResult = amountRemainingToPay * (1 + interestRate / 100 * monthsToPay);

            monthlyRepayment = tempResult / monthsToPay;
            return monthlyRepayment;
        }

        // check if student can afford the loan
        public bool CheckForAlert()
        {

            double income = Income.GetIncomeAfterTax();
            double priceCeiling = income / 3;

            if (monthlyRepayment > priceCeiling)
            {
                RedLoanAlert = true;
            }
            else
            {
                RedLoanAlert = false;
            }
            return RedLoanAlert;
        }

        // getters and setters
        public double GetPropertyPrice()
        {
            return propertyPrice;
        }

        public double GetDeposit()
        {
            return deposit;
        }

        public int GetInterestRate()
        {
            return interestRate;
        }

        public int GetMonthsToPay()
        {
            return monthsToPay;
        }

        public void SetPropertyPrice(double propertyPrice)
        {
            this.propertyPrice = propertyPrice;
        }

        public void SetDeposit(double deposit)
        {
            this.deposit = deposit;
        }

        public void SetInterestRate(int interestRate)
        {
            this.interestRate = interestRate;
        }

        public void SetMonthsToPay(int monthsToPay)
        {
            this.monthsToPay = monthsToPay;
        }
    }
}
